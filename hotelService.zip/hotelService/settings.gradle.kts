rootProject.name = "hotelService"
